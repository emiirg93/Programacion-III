<?php

    $arrayLista = array();

   
        if(file_exists("ListaDeAlumnos.txt"))
        {
           $archivo = fopen("ListaDeAlumnos.txt","r");
           
           while(!feof($archivo))
           {
               array_push($arrayLista,fgets($archivo));
           }

           fclose($archivo);

           var_dump($arrayLista);

        }     

?>