<?php
include_once "Persona.php";

class Alum extends Persona
{
    public $legajo;

    function __construct($leg,$nom,$edad,$dni)
    {
        parent::__construct($nom,$edad,$dni);
        $this->legajo = $leg;
    }
    

}

?>