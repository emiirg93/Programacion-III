<?php
include "Alumno.php";

//$nombre = "Emiliano";

//echo $nombre;

//var_dump($nombre);

//$miArray = array("Nombre" => "Emiliano","Edad"=>25);

$miArray = array();

$miArray["Nombre"] ="Emiliano";
$miArray["Edad"] = 22;

$miObjeto = new stdClass(); // creacion de una clase estandar.

$miObjeto ->Nombre = "Emilio";
$miObjeto ->Edad = 28; 

var_dump($miArray);

echo "<br>";

var_dump($miObjeto);

/*$miAlumno = new Alumno();
$miAlumno->nombre = "Pepito";
$miAlumno->edad = 15;*/

echo"<br>";

// var_dump($miAlumno);

$otroAlumno = new Alumno(1258,"Emiliano",25,37904306);

//var_dump($otroAlumno);

echo $otroAlumno->retornarJson();



?>