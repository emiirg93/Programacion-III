<?php

class alumno
{
    public $Nombre;
    public $Edad;
    
    function __construct($nom,$ed)
    {
        $this->Nombre = $nom;
        $this->Edad = $ed;
    }

    public function RetornarJson()
    {
        return json_encode($this);
    }
}


?>