<?php

class alumno
{
    public $Nombre;
    public $Edad;
    
    function __construct($nom,$ed)
    {
        $this->Nombre = $nom;
        $this->Edad = $ed;
    }

    public function RetornarJson()
    {
        return json_encode($this);
    }

    public function GuardarAlumno()
    {

        if(file_exists("ListaDeAlumnos.txt"))
        {
            $file = fopen("ListaDeAlumnos.txt", "a");

            fwrite($file,"$this->Nombre , $this->Edad \r\n");

            fclose($file);
        }
        else
        {
            $file = fopen("ListaDeAlumnos.txt", "w");
            fwrite($file,"$this->Nombre , $this->Edad\r\n");

            fclose($file);
        }
        
    }

    public function GuardarJson()
    {

        if(file_exists("ListadoJson.json"))
        {
            $file = fopen("ListadoJson.json", "a");

            $Listadojson = $this->RetornarJson()."\r\n";
            fwrite($file,$Listadojson);
        }
        else
        {
            $file = fopen("ListadoJson.json", "w");

            $Listadojson = $this->RetornarJson()."\r\n";
            fwrite($file,$Listadojson);
        }
        
        fclose($file);
    }
}


?>