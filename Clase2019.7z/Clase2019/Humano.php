<?php

class Humano
{
    $Nombre;
    $Edad;

    function __construct($nom,$ed)
    {
        $this->Nombre = $nom;
        $this->Edad = $ed;
    }
}


?>