<?php
include_once "Humano.php";

class Persona extends Humano
{
    public $DNI;

    function __construct($dni,$nom,$edad)
    {
        parent:: __construct($nom,$edad);
        $this->DNI = $dni;
    }

}

?>