<?php
include_once "Alumno.php";

$nombre = $_POST["Nombre"];
$edad = $_POST["Edad"];

$alumnoCreado = new Alumno($nombre,$edad);

echo $alumnoCreado->retornarJson();

?>