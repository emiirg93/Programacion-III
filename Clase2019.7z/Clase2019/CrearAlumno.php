<?php
include_once "Alumno.php";

$nombre = $_POST["Nombre"];
$edad = $_POST["Edad"];

$arrayAlumno = array();

$arrayAlumno = new Alumno($nombre,$edad);



echo $arrayAlumno->retornarJson();

$arrayAlumno->GuardarAlumno();
$arrayAlumno->GuardarJson();

?>