<?php

include_once "../src/materia.php";
include_once "../src/AutentificadorJWT.php";
include_once "../src/AccesoDatos.php";

class materiaApi extends materia
{
    public function altaMateria($request, $response, $args)
    {
        $objetoRespuesta = new stdClass();
        $arrayDeParametros = $request->getParsedBody();

        //var_dump($arrayDeParametros);

        $name = $arrayDeParametros['nombre'];
        $key = $arrayDeParametros['cuatrimestre'];
        $tipe = $arrayDeParametros['cupos'];

        $user = new materia();
        $user->nombre = $name;
        $user->cuatrimestre = $key;
        $user->cupos = $tipe;

        if ($user->InsertarDB()) {
            $objetoRespuesta->respuesta = "Se Guardo La Materia";
        } else {
            $objetoRespuesta->respuesta = "error! Usuario Materia No Guardada";
        }

        return $objetoRespuesta->respuesta;
    }
}
