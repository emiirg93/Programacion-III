<?php

include_once "../src/usuario.php";
include_once "../src/AutentificadorJWT.php";
include_once "../src/AccesoDatos.php";

class usuarioApi extends usuario
{
    public function alta($request, $response, $args)
    {
        $objetoRespuesta = new stdClass();
        $arrayDeParametros = $request->getParsedBody();

        //var_dump($arrayDeParametros);

        $name = $arrayDeParametros['usuario'];
        $key = $arrayDeParametros['clave'];
        $tipe = $arrayDeParametros['tipo'];

        $user = new usuario();
        $user->usuario = $name;
        $user->clave = $key;
        $user->tipo = $tipe;

        if ($user->InsertarDB()) {
            $objetoRespuesta->respuesta = "Se Guardo El Usuario";
        } else {
            $objetoRespuesta->respuesta = "error! Usuario No Guardado";
        }

        return $objetoRespuesta->respuesta;

    }

    public function _login($request, $response, $args)
    {
        $objDelaRespuesta = new stdclass();

        $passwordParametero = $request->getParsedBody();
        $user = $passwordParametero["usuario"];
        $pass = $passwordParametero["clave"];

        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

        $consulta = $objetoAccesoDato->RetornarConsulta("select * from usuario
                                                        where usuario = :user
                                                        and clave = :pass");

        $consulta->bindValue(':user', $user, PDO::PARAM_STR);
        $consulta->bindValue(':pass', $pass, PDO::PARAM_STR);

        $consulta->execute();
        $usuario = $consulta->fetchObject("usuario");

        if ($usuario != false) {
            $usuarioToken = new stdclass();
            $usuarioToken->usuario = $usuario->usuario;
            $usuarioToken->id = $usuario->id;
            $usuarioToken->tipo = $usuario->tipo;

            if ($usuario->clave == $passwordParametero["clave"]) {
                $objDelaRespuesta->respuesta = "Bienvenido@ " . $passwordParametero["usuario"];
                $objDelaRespuesta->legajo = $usuario->id;
                $token = AutentificadorJWT::CrearToken($usuarioToken);
                $objDelaRespuesta->token = $token;
                $objDelaRespuesta->status = 200;
            }
        } else {
            $objDelaRespuesta->respuesta = "La clave, sexo o el nombre ingresado no existe";
            $objDelaRespuesta->status = 500;
        }
        return $objDelaRespuesta;
    }

}
