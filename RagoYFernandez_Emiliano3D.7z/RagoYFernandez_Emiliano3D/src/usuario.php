<?php

include_once "../src/AccesoDatos.php";

class usuario
{
    public $usuario;
    public $clave;
    public $tipo;

    public function InsertarDB()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into usuario (usuario,clave,tipo)values(:usuario,:clave,:tipo)");
        $consulta->bindValue(':usuario', $this->usuario, PDO::PARAM_STR);
        $consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
        $consulta->bindValue(':tipo', $this->tipo, PDO::PARAM_STR);
        $consulta->execute();
        return $objetoAccesoDato->RetornarUltimoInsertado();
    }

    public function Insertarusuario()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into usuario (usuario,clave,tipo)values('$this->usuario','$this->clave','$this->tipo')");
        $consulta->execute();
        return $objetoAccesoDato->RetornarUltimoInsertado();
    }
}
