<?php

include_once "../src/AccesoDatos.php";

class materia
{
    public $nombre;
    public $cuatrimestre;
    public $cupos;

    public function InsertarDB()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta = $objetoAccesoDato->RetornarConsulta("INSERT into materia (nombre,cuatrimestre,cupos)values(:nombre,:cuatrimestre,:cupos)");
        $consulta->bindValue(':nombre', $this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':cuatrimestre', $this->cuatrimestre, PDO::PARAM_STR);
        $consulta->bindValue(':cupos', $this->cupos, PDO::PARAM_STR);
        $consulta->execute();
        return $objetoAccesoDato->RetornarUltimoInsertado();
    }
}
