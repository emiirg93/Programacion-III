<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

include_once '../src/usuarioApi.php';
include_once '../src/materiaApi.php';
include_once '../src/MWAutentificar.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->post('/usuario', function (Request $request, Response $response, array $args) use ($container) {
        $response->write(json_encode(usuarioApi::alta($request, $response, $args)));
    });

    $app->post('/login', function (Request $request, Response $response, array $args) use ($container) {
        $response->write(json_encode(usuarioApi::_login($request, $response, $args)));
    });

    $app->post('/materia', function (Request $request, Response $response, array $args) use ($container) {
        $response->write(json_encode(materiaApi::altaMateria($request, $response, $args)));
    })->add(\MWAutentificar::class . ':VerificarUsuario');

};
